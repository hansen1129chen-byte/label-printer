CREATE TABLE IF NOT EXISTS alert_config (
  id INT AUTO_INCREMENT PRIMARY KEY,
  config_key VARCHAR(50) NOT NULL UNIQUE,
  config_value VARCHAR(100) NOT NULL DEFAULT '',
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;
INSERT IGNORE INTO alert_config (config_key, config_value) VALUES ('pending_alert_hours', '24'), ('in_transit_alert_hours', '72');
